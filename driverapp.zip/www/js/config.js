/*Driver App Configuration*/

var krms_driver_config ={			
	'ApiUrl':"https://pedeagora.hospteste.ga/driver/api",		
	'DialogDefaultTitle':"DriverApp",
	'mapboxToken' : 'pk.eyJ1Ijoid2VzbGxleXRoMTUiLCJhIjoiY2p1eGIwMmdjMGtrbDN5cnZsajFidzRuMiJ9.XW8Mz_nrCC_nT4nOM4pMcQ',
	'APIHasKey':"asd564sad987sd52a4165sd4a8974sd5a46",
	'debug': false
};